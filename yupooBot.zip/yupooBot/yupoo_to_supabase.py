#!/usr/bin/env python3
"""Import Yupoo albums into Alves Store Supabase Storage and products table.

Dependencies: requests, beautifulsoup4, Pillow (optional but recommended).
Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in the environment. Never use
the service role key in a browser or commit it to the repository.
"""
from __future__ import annotations

import argparse
import base64
import io
import json
import os
import re
import sys
import time
import unicodedata
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

try:
    from PIL import Image
except ImportError:
    Image = None

STORE_SIZES = ["P", "M", "G", "GG", "2GG"]
SIZE_CODES = ["XS", "S", "M", "L", "XL", "XXL"]
SIZE_LABELS = {"XS": "PP", "S": "P", "M": "M", "L": "G", "XL": "GG", "XXL": "2GG"}
LEAGUE_ALIASES = {
    "brasileirao": "brasileirao-serie-a", "brasileirão": "brasileirao-serie-a",
    "premier league": "premier-league", "la liga": "la-liga",
    "serie a": "campeonato-italiano", "bundesliga": "campeonato-alemao",
    "ligue 1": "campeonato-frances", "selecoes": "selecoes", "seleções": "selecoes",
}


def slugify(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    return re.sub(r"-+", "-", re.sub(r"[^a-z0-9]+", "-", value.lower())).strip("-")[:100]


def clean_title(value: str) -> str:
    value = re.sub(r"\s*\|\s*Yupoo.*$", "", value, flags=re.I)
    value = re.sub(r"\b(?:XS|S|M|L|XL|XXL|XXXL|S-XXL|S-2XL|M-3XL|2XL|3XL)\b", " ", value, flags=re.I)
    value = re.sub(r"(?<!\d)\d{5,}(?!\d)", " ", value)  # numeric Yupoo stock codes
    value = re.sub(r"\b(?:fan version|supporter version|player version)\b", " ", value, flags=re.I)
    value = re.sub(r"[\[\]{}()_]+", " ", value)
    return re.sub(r"\s+", " ", value).strip(" -|·")[:140]


def sizes_from_title(value: str):
    upper = value.upper().replace("2XL", "XXL")
    match = re.search(r"\b(XS|S|M|L|XL|XXL)\s*[-~]\s*(XXL|XL|L|M|S|XS)\b", upper)
    if match:
        start, end = SIZE_CODES.index(match.group(1)), SIZE_CODES.index(match.group(2))
        if start <= end:
            return [SIZE_LABELS[code] for code in SIZE_CODES[start:end + 1]]
    # Yupoo album titles often encode only a continuous range; without one,
    # retain the store's most common registered adult grade.
    return STORE_SIZES.copy()


def get_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(total=5, connect=5, read=5, backoff_factor=1.2,
                  status_forcelist=(429, 500, 502, 503, 504), allowed_methods=("GET", "PUT", "POST"))
    session.mount("https://", HTTPAdapter(max_retries=retry))
    session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36"})
    return session


def category_albums(url: str, session: requests.Session, referer: str, delay: float):
    seen, page = set(), 1
    while True:
        page_url = url if page == 1 else f"{url}{'&' if '?' in url else '?'}page={page}"
        response = session.get(page_url, headers={"Referer": referer}, timeout=30)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        found = []
        for anchor in soup.select("a[href*='/albums/']"):
            href = anchor.get("href", "").split("?", 1)[0]
            full_url = urljoin(referer, href)
            if full_url not in seen:
                seen.add(full_url)
                found.append((full_url, anchor.get("title") or anchor.get_text(" ", strip=True)))
        if not found:
            break
        yield from found
        page += 1
        time.sleep(delay)


def album_photos(url: str, suggested_title: str, session: requests.Session, referer: str):
    response = session.get(url, headers={"Referer": referer}, timeout=40)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    title_node = soup.select_one(".showalbumheader__gallerytitle") or soup.select_one("h1, h2") or soup.title
    title = title_node.get_text(" ", strip=True) if title_node else suggested_title
    photos = []
    for image in soup.select(".image__imagewrap img, .showalbum__children img, img"):
        src = image.get("data-origin-src") or image.get("data-src") or image.get("src")
        if not src:
            continue
        src = urljoin(referer, src)
        if "photo.yupoo.com" not in urlparse(src).netloc:
            continue
        src = re.sub(r"/(?:small|medium|thumb)\.", "/big.", src)
        if src not in photos:
            photos.append(src)
    return title or suggested_title, photos


def read_leagues(project_root: Path):
    try:
        data = json.loads((project_root / "data" / "leagues.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    return data


def classify(title: str, category: str, leagues: list):
    normalized = unicodedata.normalize("NFKD", f"{title} {category}").encode("ascii", "ignore").decode().lower()
    category_key = slugify(category)
    league_slug = LEAGUE_ALIASES.get(category.strip().lower(), category_key)
    for league in leagues:
        if league["slug"] == category_key or slugify(league["nome"]) == category_key:
            league_slug = league["slug"]
            break
    club = next((club for league in leagues for club in sorted(league.get("clubes", []), key=lambda c: len(c["nome"]), reverse=True)
                 if re.search(r"\b" + re.escape(unicodedata.normalize("NFKD", club["nome"]).encode("ascii", "ignore").decode().lower()) + r"\b", normalized)), None)
    club_name, club_slug = (club["nome"], club["slug"]) if club else ("revisar", "revisar")
    if re.search(r"\b(kids?|infantil|youth)\b", normalized):
        audience, kind, price = "infantil", "revisar", 0
    elif re.search(r"\b(wind ?breaker|jacket|coat|agasalho|corta vento)\b", normalized):
        audience, kind, price = "masculino", "inverno", 0
    elif re.search(r"\b(cropped|dress|vestido|tank|regata|training|treino)\b", normalized):
        audience, kind, price = "masculino", ("cropped" if "cropped" in normalized else "vestido" if "vestido" in normalized or "dress" in normalized else "regata" if "regata" in normalized or "tank" in normalized else "treino"), 0
    elif re.search(r"\b(goalkeeper|keeper|goleiro|gk)\b", normalized):
        audience, kind, price = "masculino", "goleiro", 160
    elif re.search(r"\b(retro|retro|vintage|classic)\b", normalized):
        audience, kind = "masculino", "retro"
        price = 220 if re.search(r"\b(long sleeve|manga longa|\bls\b)\b", normalized) else 185
    elif re.search(r"\b(player|jogador)\b", normalized):
        audience, kind = "masculino", "jogador"
        price = 220 if re.search(r"\b(long sleeve|manga longa|\bls\b)\b", normalized) else 0
    else:
        audience, kind = "masculino", "torcedor"
        price = 180 if re.search(r"\b(full ?patch|all sponsors|patch completo)\b", normalized) else 160
    temporada = "revisar"
    match = re.search(r"\b(20\d{2})\s*[-/]\s*(\d{2,4})\b|\b(\d{2})\s*[-/]\s*(\d{2})\b", title)
    if match:
        if match.group(1):
            temporada = f"{match.group(1)[-2:]}/{match.group(2)[-2:]}"
        else:
            temporada = f"{match.group(3)}/{match.group(4)}"
    uniform = "revisar"
    for key, value in ((r"\b(home|titular)\b", "titular"), (r"\b(away|reserva|visitor)\b", "reserva"), (r"\b(third|3rd|terceiro)\b", "terceiro"), (r"\b(fourth|4th|quarto)\b", "quarto")):
        if re.search(key, normalized):
            uniform = value
            break
    return {"clube": club_name, "clubeSlug": club_slug, "liga": league_slug, "publico": audience,
            "tipo": kind, "temporada": temporada, "uniforme": uniform, "preco": price,
            "tamanhos": STORE_SIZES if price else []}


def optimize_image(content: bytes):
    if Image is None:
        if content.startswith(b"\x89PNG\r\n\x1a\n"):
            return content, "image/png", "png", ""
        if content.startswith(b"GIF8"):
            return content, "image/gif", "gif", ""
        return content, "image/jpeg", "jpg", ""
    with Image.open(io.BytesIO(content)) as source:
        image = source.convert("RGB")
        image.thumbnail((1800, 1800), Image.Resampling.LANCZOS)
        tiny = image.copy()
        tiny.thumbnail((24, 24), Image.Resampling.LANCZOS)
        blur_buffer = io.BytesIO()
        tiny.save(blur_buffer, format="WEBP", quality=35)
        blur_data_url = "data:image/webp;base64," + base64.b64encode(blur_buffer.getvalue()).decode("ascii")
        output = io.BytesIO()
        image.save(output, format="WEBP", quality=82, method=6)
        return output.getvalue(), "image/webp", "webp", blur_data_url


def storage_upload(session, base_url: str, service_key: str, object_path: str, body: bytes, content_type: str):
    response = session.put(f"{base_url}/storage/v1/object/produtos/{object_path}", data=body,
                           headers={"Authorization": f"Bearer {service_key}", "apikey": service_key,
                                    "Content-Type": content_type, "x-upsert": "true"}, timeout=90)
    response.raise_for_status()
    return f"{base_url}/storage/v1/object/public/produtos/{object_path}"


def import_album(url, suggested, category, session, referer, base_url, service_key, leagues, delay):
    title, sources = album_photos(url, suggested, session, referer)
    if not sources:
        print(f"Sem imagens: {title}", file=sys.stderr)
        return None
    album_id_match = re.search(r"/albums/([^/?#]+)", url)
    yupoo_id = album_id_match.group(1) if album_id_match else slugify(url)
    clean = clean_title(title)
    slug = f"{slugify(clean) or 'produto'}-{slugify(yupoo_id)[:8]}"
    facts = classify(clean, category, leagues)
    if facts["preco"] > 0:
        facts["tamanhos"] = sizes_from_title(title)
    images = []
    for index, source in enumerate(sources, 1):
        response = session.get(source, headers={"Referer": referer}, timeout=60)
        response.raise_for_status()
        body, content_type, extension, blur_data_url = optimize_image(response.content)
        public_url = storage_upload(session, base_url, service_key, f"{slug}/{index:02d}.{extension}", body, content_type)
        images.append({"src": public_url, "source": url, "alt": f"{clean} - foto {index}",
                       "credit": f"Imagem importada do álbum Yupoo {url}",
                       "focalPoint": {"x": 50, "y": 50}, "blurDataURL": blur_data_url})
        time.sleep(delay)
    product = {"id": f"yupoo-{slugify(yupoo_id)}", "yupoo_id": yupoo_id, "slug": slug,
               **facts, "nome": clean, "cor": "revisar", "imageSeed": slug, "images": images}
    response = session.post(f"{base_url}/rest/v1/products?on_conflict=yupoo_id", json=product,
                            headers={"Authorization": f"Bearer {service_key}", "apikey": service_key,
                                     "Content-Type": "application/json", "Prefer": "resolution=merge-duplicates,return=minimal"}, timeout=60)
    response.raise_for_status()
    return product


def main():
    parser = argparse.ArgumentParser(description="Importa uma categoria ou álbum Yupoo para o Supabase.")
    parser.add_argument("url", help="URL da categoria/coleção ou álbum Yupoo")
    parser.add_argument("--category", required=True, help="Categoria/liga informada, por exemplo Brasileirão")
    parser.add_argument("--project-root", type=Path, default=Path.cwd(), help="Raiz lojaMarco para ler data/leagues.json")
    parser.add_argument("--delay", type=float, default=0.5, help="Intervalo entre requisições (segundos)")
    args = parser.parse_args()
    base_url = os.getenv("SUPABASE_URL", os.getenv("NEXT_PUBLIC_SUPABASE_URL", "")).rstrip("/")
    service_key = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")
    if not base_url or not service_key:
        parser.error("Defina SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY no ambiente.")
    host = urlparse(args.url)
    if host.scheme != "https" or not host.netloc:
        parser.error("Informe uma URL Yupoo HTTPS válida.")
    referer = f"{host.scheme}://{host.netloc}/"
    session = get_session()
    leagues = read_leagues(args.project_root)
    is_album = "/albums/" in args.url
    albums = [(args.url, "")] if is_album else list(category_albums(args.url, session, referer, args.delay))
    print(f"Álbuns encontrados: {len(albums)}")
    completed = 0
    for index, (album_url, suggested) in enumerate(albums, 1):
        try:
            result = import_album(album_url, suggested, args.category, session, referer, base_url, service_key, leagues, args.delay)
            if result:
                completed += 1
                print(f"[{index}/{len(albums)}] Importado: {result['nome']} ({result['tipo']}, R$ {result['preco']:.2f})")
        except (requests.RequestException, ValueError) as error:
            print(f"[{index}/{len(albums)}] Falha em {album_url}: {error}", file=sys.stderr)
        time.sleep(args.delay)
    print(f"Concluído: {completed}/{len(albums)} álbuns importados.")


if __name__ == "__main__":
    main()
